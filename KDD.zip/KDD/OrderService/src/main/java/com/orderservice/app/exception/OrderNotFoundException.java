package com.orderservice.app.exception;


public class OrderNotFoundException extends RuntimeException {
	public OrderNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
