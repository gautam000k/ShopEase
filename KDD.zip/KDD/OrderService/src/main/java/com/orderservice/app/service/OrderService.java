package com.orderservice.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.orderservice.app.entity.Order;
import com.orderservice.app.entity.Status;

public interface OrderService {
	 List<Order>getAllOrders();

	 List<Order> getOrderByCustomerId(int customerId);

	 Order placeOrder(Order order);

	 Order changeOrderStatus(Status orderStatus, int orderId);

	 String cancelOrder(int orderId);



}
