package com.orderservice.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.orderservice.app.entity.Cart;
import com.orderservice.app.entity.Items;
import com.orderservice.app.entity.Order;
import com.orderservice.app.entity.Status;
import com.orderservice.app.exception.CartNotFoundException;
//import com.orderservice.app.entity.Product;
//import com.orderservice.app.entity.UserProfile;
import com.orderservice.app.exception.OrderNotFoundException;
import com.orderservice.app.repository.OrderRepository;
//import com.orderservice.app.repository.ProfileRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;
	@Autowired
	private RestTemplate restTemplate;

	

	@Override
	public  Order placeOrder(Order order) {
		Cart cart = restTemplate.getForObject("http://cartservice/carts/getCart/" +order.getCartId(), Cart.class);
		 if(cart==null)
		 {
			 throw new CartNotFoundException("Your Cart is Empty");
		 }
		double orderTotal = cart.getTotalPrice();
		order.setAmountPaid(orderTotal);
		order.setOrderStatus(Status.PLACED);
		for (Items it : cart.getItems()) {
			order.addItem(it.getProductId());
		}
		restTemplate.delete("http://cartservice/carts/deleteCart/"+order.getCartId());

		// Logic to place order
	
		return orderRepository.save(order);
	}

	@Override
	public  List<Order> getAllOrders() {
		List<Order> orders = orderRepository.findAll();
		if (orders.size() == 0)
			throw new OrderNotFoundException("No Orders found!!");
		return orders;
	}

	@Override
	public  List<Order> getOrderByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		
		List<Order>orderList=orderRepository.findByCustomerId(customerId);
		if (orderList.isEmpty()) {
		        throw new OrderNotFoundException("You have not ordered yet!");
		    }
		return orderRepository.findByCustomerId(customerId);
	}

	@Override
	public  Order changeOrderStatus(Status orderStatus, int orderId) {
		// TODO Auto-generated method stub
     Order order=orderRepository.findById(orderId).orElseThrow(()-> new OrderNotFoundException("Order not found with ID " + orderId));
		
		order.setOrderStatus(orderStatus);
		return orderRepository.save(order);

	}

	@Override
	public  String cancelOrder(int orderId) {
		// TODO Auto-generated method stub
		Optional<Order> order = orderRepository.findById(orderId);

		if (!order.isEmpty()) {
			orderRepository.delete(order.get());
			return "Successfully Deleted";
		} else {
			throw new OrderNotFoundException("Order not found with ID " + orderId);
		}
	}
	

}
