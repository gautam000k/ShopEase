package com.orderservice.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orderservice.app.entity.Order;
import com.orderservice.app.entity.Status;
import com.orderservice.app.service.OrderService;

import jakarta.validation.Valid;
import jakarta.ws.rs.Path;

@RestController
@RequestMapping("/orders")
public class OrderServiceController {
	
	@Autowired
	OrderService  orderService;
	
	@GetMapping("/getAllOrders")
	public ResponseEntity<List<Order>> getAllOrders()
	{
		List<Order>orders= orderService.getAllOrders();
	return new ResponseEntity<>(orders,HttpStatus.OK);
	}
	
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<Order>> getOrderByCustomerId(@PathVariable int customerId)
	{
		
	List<Order>orders=	orderService.getOrderByCustomerId(customerId);
		return   new ResponseEntity<>(orders,HttpStatus.OK);
	}
	@PostMapping("/placeOrder")
	public ResponseEntity<Order> placeOrder(@Valid @RequestBody Order order)
	{
		Order orders= orderService.placeOrder(order);
		return new ResponseEntity<>(orders,HttpStatus.CREATED);
		
	}
	
	@PutMapping("changeOrderStatus/{orderId}")
	public ResponseEntity<Order> changeOrderStatus(@Valid @RequestBody Status orderStatus,@PathVariable int orderId)
	{
	Order orders=	orderService.changeOrderStatus(orderStatus,orderId);
	return new ResponseEntity<>(orders,HttpStatus.OK);
	
		
	}
	
	 @DeleteMapping("cancelOrder/{orderId}")
	 public ResponseEntity<String> cancelOrder(@PathVariable int orderId){
		 
		 
		String orders= orderService.cancelOrder(orderId);
		
		return new ResponseEntity<>(orders,HttpStatus.OK);
	 }

}
