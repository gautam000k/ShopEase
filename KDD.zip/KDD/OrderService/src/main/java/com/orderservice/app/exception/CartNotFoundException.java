package com.orderservice.app.exception;


public class CartNotFoundException extends RuntimeException {
	public CartNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
