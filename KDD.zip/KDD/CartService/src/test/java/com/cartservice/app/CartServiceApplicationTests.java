package com.cartservice.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = CartServiceApplication.class)
class CartServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
