package com.example.service;

import org.springframework.http.ResponseEntity;

import com.example.dto.MailDetails;

public interface EmailService {
	public ResponseEntity<?> sendMail(MailDetails details);
	
	public ResponseEntity<?> registerUser(String email);
}
