package com.example.controller;

import java.net.ResponseCache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.MailDetails;
import com.example.service.EmailService;


@RestController
@RequestMapping("/notification")
public class EmailContorller {
	
	@Autowired 
	private EmailService service;
	
	@PostMapping("/sendMail")
	public ResponseEntity<?> sendMail(@RequestBody MailDetails details){
		System.out.println(details);
		return service.sendMail(details);
	}
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody String email){
		service.registerUser(email);
		return  ResponseEntity.ok("User registered sucessfully and email sent");
		
		
	}
	
}
