//package com.project.service;
//
//
//
//import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.BadCredentialsException;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//
//import com.userservice.app.entity.User;
//import com.userservice.app.repository.UserRepository;
//import com.userservice.app.security.JwtTokenUtil;
//import com.userservice.app.service.UserServiceImpl;
//
//
//public class UserServiceImplTest {
//
//	@Mock
//	private UserRepository userRepository;
//
//	@Mock
//	private OrderClient orderClient;
//
//	@Mock
//	private CartClient cartClient;
//
//	@Mock
//	private UserDetailsService userDetailsService;
//
//	@Mock
//	private AuthenticationManager manager;
//
//	@Mock
//	private JwtTokenUtil helper;
//
//	@InjectMocks
//	private UserServiceImpl userService;
//
//	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
//
//	@BeforeEach
//	public void setUp() {
//		MockitoAnnotations.openMocks(this);
//	}
//
//	@Test
//	public void testCreateProfile() {
//		User user = new User(0, "John Doe", "http://example.com/image.jpg", "john.doe@example.com",
//				1234567890L, "About John", new Date(95, 1, 1), "Male", "ADMIN", "password123", List.of());
//
//		when(userRepository.findByEmailId("john.doe@example.com")).thenReturn(null);
//		when(userRepository.save(any(User.class))).thenReturn(user);
//
//		ResponseEntity<String> response = userService.createUser(user);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertNotNull(response.getBody());
//	}
//
//	@Test
//	public void testGetAllProfiles() {
//		User user1 = new User(1, "John Doe", "http://example.com/image.jpg",
//				"john.doe@example.com", 1234567890L, "About John", new Date(95, 1, 1), "Male", "Admin", "password123",
//				List.of());
//		User user2 = new User(2, "Jane Smith", "http://example.com/image2.jpg",
//				"jane.smith@example.com", 1234567891L, "About Jane", new Date(90, 5, 15), "Female", "User",
//				"password456", List.of());
//
//		when(userRepository.findAll()).thenReturn(List.of(user1, user2));
//
//		ResponseEntity<List<UserProfile>> response = userService.getAllUsers();
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertNotNull(response.getBody());
//		assertEquals(2, response.getBody().size());
//	}
//
//	@Test
//	public void testDeleteProfile() {
//		User user = new User(1, "John Doe", "http://example.com/image.jpg", "john.doe@example.com",
//				1234567890L, "About John", new Date(95, 1, 1), "Male", "Admin", "password123", List.of());
//
//		when(userRepository.findById(1)).thenReturn(Optional.of(user));
//
//		ResponseEntity<String> response = userService.deleteUser(1);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertEquals("Profile deleted successfully", response.getBody());
//
//		verify(profileRepository, times(1)).delete(userProfile);
//	}
//
//	@Test
//	public void testUpdateProfile() {
//		UserProfile existingProfile = new UserProfile(1, "John Doe", "http://example.com/image.jpg",
//				"john.doe@example.com", 1234567890L, "About John", new Date(95, 1, 1), "Male", "Admin", "password123",
//				List.of());
//		UserProfile updatedProfile = new UserProfile(1, "John Doe Updated", "http://example.com/image.jpg",
//				"john.doe@example.com", 1234567890L, "About John Updated", new Date(95, 1, 1), "Male", "Admin",
//				"newpassword123", List.of());
//
//		when(profileRepository.findById(1)).thenReturn(Optional.of(existingProfile));
//		when(profileRepository.save(any(UserProfile.class))).thenReturn(updatedProfile);
//
//		ResponseEntity<String> response = profileService.updateProfile(1, updatedProfile);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertNotNull(response.getBody());
//
//	}
//
//	@Test
//	public void testGetProfileById() {
//		UserProfile userProfile = new UserProfile(1, "John Doe", "http://example.com/image.jpg", "john.doe@example.com",
//				1234567890L, "About John", new Date(95, 1, 1), "Male", "Admin", "password123", List.of());
//
//		when(profileRepository.findById(1)).thenReturn(Optional.of(userProfile));
//
//		ResponseEntity<UserProfile> response = profileService.getProfileById(1);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertNotNull(response.getBody());
//		assertEquals("John Doe", response.getBody().getFullName());
//	}
//
//	@Test
//	public void testGetOrders() {
//		Order order1 = new Order();
//		order1.setOrderId(1);
//
//		order1.setCustomerId(1);
//		order1.setOrderStatus("Shipped");
//
//		Order order2 = new Order();
//		order2.setOrderId(2);
//		order2.setCustomerId(1);
//		order2.setOrderStatus("Delivered");
//
//		when(profileRepository.findById(1)).thenReturn(Optional.of(new UserProfile()));
//		when(orderClient.getOrderByCustomerId(1)).thenReturn(ResponseEntity.ok(List.of(order1, order2)));
//
//		ResponseEntity<List<Order>> response = profileService.getOrders(1);
//		assertEquals(HttpStatus.OK, response.getStatusCode());
//		assertNotNull(response.getBody());
//		assertEquals(2, response.getBody().size());
//	}
//
//	@Test
//	public void testGetProfileByEmailId() {
//		UserProfile userProfile = new UserProfile(1, "John Doe", "http://example.com/image.jpg", "john.doe@example.com",
//				1234567890L, "About John", new Date(95, 1, 1), "Male", "Admin", "password123", List.of());
//
//		when(profileRepository.findByEmailId("john.doe@example.com")).thenReturn(userProfile);
//
//		UserProfile response = profileService.getProfileByEmailId("john.doe@example.com");
//		assertNotNull(response);
//		assertEquals("John Doe", response.getFullName());
//	}
//
//	@Test
//	public void testAuthenticateInvalidCredentials() {
//		doThrow(new BadCredentialsException("Invalid Username or Password")).when(manager).authenticate(any());
//
//		assertThrows(BadCredentialsException.class, () -> {
//			profileService.login(new JwtRequest("john.doe@example.com", "wrongPassword"));
//		});
//	}
//}
