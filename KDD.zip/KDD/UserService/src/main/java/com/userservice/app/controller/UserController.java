package com.userservice.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.userservice.app.entity.Cart;
import com.userservice.app.entity.Order;
import com.userservice.app.entity.User;
import com.userservice.app.service.UserService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;

	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") int userId) {
		return userService.getUserById(userId);
	}

	@GetMapping("/email/{emailId}")
	public User getUserByEmailId(@PathVariable("emailId") String emailId) {
		return userService.getUserByEmailId(emailId);
	}

	@GetMapping("/getAllUsers")
	public ResponseEntity<List<User>> getAllUsers() {
		return userService.getAllUsers();

	}
	@PutMapping("/{userId}")
	public ResponseEntity<String> updateUser(@PathVariable int userId, @RequestBody User user) {

		return userService.updateUser(userId, user);

	}

	@GetMapping("/cart/{customerId}")
	public ResponseEntity<List<Cart>> getCartsByCustomerId(@PathVariable("customerId") int customerId) {
		return userService.getCart(customerId);
	}

	@GetMapping("/orders/{customerId}")
	public ResponseEntity<List<Order>> getOrdersByCustomerId(@PathVariable("customerId") int customerId) {
		return userService.getOrders(customerId);
	}

	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable int userId) {
		return userService.deleteUser(userId);
	}

}
