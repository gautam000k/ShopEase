package com.userservice.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.userservice.app.entity.User;
import com.userservice.app.exception.UserNotFoundException;
import com.userservice.app.repository.UserRepository;
import com.userservice.app.security.UserTokenDetails;


@Service
public class MyUserDetailsService  implements UserDetailsService{

	@Autowired
	UserRepository userRepository;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User userProfile = userRepository.findByEmailId(username);
		if(userProfile==null)
		{
			throw new UserNotFoundException("User not found with this email id");
		}
		return new UserTokenDetails(userProfile);
	}

}
