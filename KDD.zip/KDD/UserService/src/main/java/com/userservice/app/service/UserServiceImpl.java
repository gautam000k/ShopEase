package com.userservice.app.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.userservice.app.dto.JwtRequest;
import com.userservice.app.dto.JwtResponse;
import com.userservice.app.entity.Cart;
import com.userservice.app.entity.Order;
import com.userservice.app.entity.User;
import com.userservice.app.exception.UserNotFoundException;
import com.userservice.app.repository.UserRepository;
import com.userservice.app.security.JwtTokenUtil;
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private AuthenticationManager manager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;
	@Autowired
	private RestTemplate restTemplate;
	
	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

	@Override
	public ResponseEntity<String> createUser(User user) {
		// TODO Auto-generated method stub
		if (userRepository.findByEmailId(user.getEmailId()) != null)
			throw new UserNotFoundException("User already exists");
		// TODO Auto-generated method stub
		try {

			user.setPassword(encoder.encode(user.getPassword()));
			String url="http://notificationservice/notification/register";
           String responseEntity= restTemplate.postForObject( url,user.getEmailId(), String.class);
			return new ResponseEntity<>(
					responseEntity +" with UserId:"+ userRepository.save(user).getUserId(),
					HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@Override
	public ResponseEntity<List<User>> getAllUsers() {
		// TODO Auto-generated method stub
		try {
			// TODO Auto-generated method stub
			return new ResponseEntity<>(userRepository.findAll(), HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	@Override
	public ResponseEntity<String> deleteUser(int userId) {
		// TODO Auto-generated method stub
		java.util.Optional<User> op = userRepository.findById(userId);
		if (!op.isEmpty()) {
			userRepository.delete(op.get());
			return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
		} else {
			throw new UserNotFoundException("User ID not present");
		}
		
	}

	@Override
	public ResponseEntity<String> updateUser(int userId, User user) {
		// TODO Auto-generated method stub
		try {
			Optional<User> existingProfile = userRepository.findById(userId);
			if (existingProfile.isPresent()) {
				user.setUserId(userId);
				if(user.getPassword()!=null)
				user.setPassword(encoder.encode(user.getPassword()));
				else {
					existingProfile.get().setAddresses(user.getAddresses());
					user=existingProfile.get();
				}
				User updatedUser = userRepository.save(user);
				return new ResponseEntity<>("User Updated Successfully", HttpStatus.OK);
			} else {
				throw new UserNotFoundException("User ID not present");
			}
		} catch (Exception e) {
			// TODO: handle exception
		e.printStackTrace();
			throw new UserNotFoundException("Email is already in use");
		}
		
	}

	@Override
	public ResponseEntity<User> getUserById(int userId) {
		// TODO Auto-generated method stub
		Optional<User> op = userRepository.findById(userId);
		if (op.isEmpty()) {
			throw new UserNotFoundException("User ID not present");
		}
		return new ResponseEntity<>(userRepository.findById(userId).get(), HttpStatusCode.valueOf(200));
	
	}

	@Override
	public ResponseEntity<List<Cart>> getCart(int customerId) {
		// TODO Auto-generated method stub
		if (userRepository.findById(customerId).isEmpty())
			throw new UserNotFoundException("User does not exists");
		    String url="http://CARTSERVICE/carts/customer/"+customerId;
		  
		    ResponseEntity<List<Cart>> response = restTemplate.exchange(
		            url,
		            HttpMethod.GET,
		            null,
		            new ParameterizedTypeReference<List<Cart>>() {}
		        );
          return response;
	}

	@Override
	public ResponseEntity<List<Order>> getOrders(int customerId) {
		// TODO Auto-generated method stub
		if (userRepository.findById(customerId).isEmpty())
			throw new UserNotFoundException("User does not exists");
		 String url="http://ORDERSERVICE/orders/customer/"+customerId;
		  
		    ResponseEntity<List<Order>> response = restTemplate.exchange(
		            url,
		            HttpMethod.GET,
		            null,
		            new ParameterizedTypeReference<List<Order>>() {}
		        );
       return response;
	                         
		
	}

	@Override
	public User getUserByEmailId(String emailId) {
		// TODO Auto-generated method stub
		User user = userRepository.findByEmailId(emailId);
		if (user == null) {
			throw new UserNotFoundException("User Not Found By Email"+emailId);
		}
		return user;
		
	}

	@Override
	public ResponseEntity<JwtResponse> login(JwtRequest request) {
		// TODO Auto-generated method stub
		this.doAuthenticate(request.getEmail(), request.getPassword());
		
        	User user=
                	userRepository.findByEmailId(request.getEmail());
        	UserDetails userDetails = userDetailsService.loadUserByUsername(request.getEmail());
        	String token=
        	//service.generateToken(authRequest.getUsername(),user.getRole());
        		this.jwtTokenUtil.generateToken(userDetails);
		JwtResponse response = new JwtResponse();
		response.setJwtToken(token);
		response.setRole(user.getRole().name());
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	private void doAuthenticate(String email, String password) {

		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(email, password);
		try {
			manager.authenticate(authentication);

		} catch (BadCredentialsException e) {
			throw new BadCredentialsException(" Invalid Username or Password  !!");
		}

	}

}
