package com.userservice.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.userservice.app.dto.JwtRequest;
import com.userservice.app.dto.JwtResponse;
import com.userservice.app.entity.Cart;
import com.userservice.app.entity.Order;
import com.userservice.app.entity.User;



public interface UserService {
    ResponseEntity<String> createUser(User user);
    ResponseEntity<List<User>> getAllUsers();
    ResponseEntity<String> deleteUser(int userId);
	ResponseEntity<String> updateUser(int userId, User user );
	ResponseEntity<User> getUserById(int userId);
	ResponseEntity<List<Cart>> getCart(int customerId);
	ResponseEntity<List<Order>> getOrders(int customerId);
	User getUserByEmailId(String emailId);
	 ResponseEntity<JwtResponse> login(JwtRequest request);

}
