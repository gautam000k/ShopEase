package com.userservice.app.entity;

public enum Role {
  CUSTOMER,MERCHANT,ADMIN
}
